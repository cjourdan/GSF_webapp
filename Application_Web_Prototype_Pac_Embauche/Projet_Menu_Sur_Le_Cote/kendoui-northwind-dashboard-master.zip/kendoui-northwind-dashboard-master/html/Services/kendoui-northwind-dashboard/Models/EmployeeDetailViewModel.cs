﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KendoUI.Northwind.Dashboard.Models
{
    public class EmployeeDetailViewModel
    {
        public int value { get; set; }
        public string text { get; set; }
    }
}