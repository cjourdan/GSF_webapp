﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KendoUI.Northwind.Dashboard.Models
{
    public class ShipperDetailViewModel
    {
        public int value { get; set; }
        public string text { get; set; }
    }
}